import os
import shutil
import time
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Request, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import mysql.connector
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import serial  # NEW: for Arduino communication

# SERIAL SETUP - Replace 'COM3' with your correct port (e.g., '/dev/ttyUSB0' on Linux)
try:
    arduino = serial.Serial('COM3', 9600, timeout=1)
    time.sleep(2)  # Give Arduino time to initialize
except Exception as e:
    arduino = None
    print(f"Arduino connection error: {e}")

app = FastAPI()

# Static and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load trained model and define classes
model = load_model("cnn_model/yarn_color_classifier.h5")
classes = ['blue', 'green', 'red']

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Database connection function
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="gurupoorna2306",
            database="yarn_sorting_db"
        )
        return conn
    except Exception as e:
        print(f"DB connection error: {e}")
        return None

# Homepage
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Prediction endpoint
@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    # Save uploaded file
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Preprocess image
    img = image.load_img(file_path, target_size=(64, 64))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0) / 255.0

    # Make prediction
    prediction = model.predict(x)
    label = classes[np.argmax(prediction)]

    # Send label to Arduino
    if arduino and arduino.is_open:
        try:
            arduino.write((label + '\n').encode())
            print(f"Sent to Arduino: {label}")
        except Exception as e:
            print(f"Error sending to Arduino: {e}")

    # Insert record into database
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO yarn_predictions (filename, label, timestamp) VALUES (%s, %s, NOW())",
                (file.filename, label)
            )
            conn.commit()
            cursor.close()
        except Exception as e:
            print("DB insert error:", e)
        finally:
            conn.close()

    return {"label": label}

# History page
@app.get("/history", response_class=HTMLResponse)
async def history_page(request: Request):
    return templates.TemplateResponse("history.html", {"request": request})

# Get history data
@app.get("/history/data")
def get_history_data(page: int = Query(1, ge=1), limit: int = Query(10, ge=1)):
    conn = get_db_connection()
    if not conn:
        return JSONResponse({"error": "DB connection failed"}, status_code=500)

    try:
        cursor = conn.cursor(dictionary=True)
        offset = (page - 1) * limit
        cursor.execute(
            "SELECT filename, label, timestamp FROM yarn_predictions ORDER BY timestamp DESC LIMIT %s OFFSET %s",
            (limit, offset)
        )
        rows = cursor.fetchall()

        cursor.execute("SELECT COUNT(*) AS total FROM yarn_predictions")
        total = cursor.fetchone()["total"]

        cursor.close()
        conn.close()

        data = [{
            "filename": row["filename"],
            "label": row["label"],
            "timestamp": row["timestamp"].strftime("%Y-%m-%d %H:%M:%S")
        } for row in rows]

        return {"data": data, "total": total, "page": page, "limit": limit}
    except Exception as e:
        print("Error fetching history:", e)
        return JSONResponse({"error": "Internal Server Error"}, status_code=500)

# Get live stats
@app.get("/stats")
def get_live_stats():
    conn = get_db_connection()
    if not conn:
        return JSONResponse({"error": "DB connection failed"}, status_code=500)

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT label, COUNT(*) FROM yarn_predictions GROUP BY label")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        stats = {"red": 0, "green": 0, "blue": 0}
        for label, count in rows:
            stats[label] = count

        return stats
    except Exception as e:
        print("Error fetching live stats:", e)
        return JSONResponse({"error": "Internal Server Error"}, status_code=500)
