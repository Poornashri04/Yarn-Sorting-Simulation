const ctx = document.getElementById('yarnChart').getContext('2d');

let chart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Red', 'Green', 'Blue'],
    datasets: [{
      label: 'Yarn Count',
      data: [0, 0, 0],
      backgroundColor: ['#ff4d4d', '#4dff88', '#4da6ff'],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        precision: 0
      }
    }
  }
});

async function loadLiveStats() {
  try {
    const res = await fetch('/stats');
    const data = await res.json();
    chart.data.datasets[0].data = [data.red || 0, data.green || 0, data.blue || 0];
    chart.update();
  } catch (err) {
    console.error("Failed to load stats:", err);
  }
}

async function uploadAndPredict() {
  const fileInput = document.getElementById('fileInput');
  const resultDiv = document.getElementById('result');

  if (!fileInput.files.length) {
    resultDiv.textContent = "Please select an image.";
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  try {
    const res = await fetch('/predict', { method: 'POST', body: formData });
    const data = await res.json();
    resultDiv.textContent = `Predicted: ${data.label}`;
    fileInput.value = '';
    loadLiveStats();  // Refresh live stats after prediction
  } catch (err) {
    resultDiv.textContent = "Prediction failed.";
    console.error("Error:", err);
  }
}

// Load stats on first page load
loadLiveStats();
